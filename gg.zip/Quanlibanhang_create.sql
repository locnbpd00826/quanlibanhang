-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2017-02-11 13:00:03.615

-- tables
-- Table: Hoa_Don
CREATE TABLE Hoa_Don (
    Ma_HD int NOT NULL,
    Ngay_Giao date NOT NULL,
    ID_KH varchar(10) NOT NULL,
    Tong_Tien int NOT NULL,
    MA_SP int NOT NULL,
    Khach_Hang_ID_KH int NOT NULL,
    CONSTRAINT Hoa_Don_pk PRIMARY KEY (Ma_HD)
);

-- Table: Hoa_Don_Chi_Tiet
CREATE TABLE Hoa_Don_Chi_Tiet (
    Ma_Loai_SP int NOT NULL,
    Hang_SX varchar(30) NOT NULL,
    Hoa_Don_Ma_HD int NOT NULL,
    San_Pham_Ma_SP int NOT NULL,
    CONSTRAINT Hoa_Don_Chi_Tiet_pk PRIMARY KEY (Ma_Loai_SP)
);

-- Table: Khach_Hang
CREATE TABLE Khach_Hang (
    ID_KH int NOT NULL,
    Ho_Ten varchar(50) NOT NULL,
    Email varchar(20) NOT NULL,
    SDT int NOT NULL,
    Dia_Chi varchar(60) NOT NULL,
    Ngay_Sinh date NOT NULL,
    Gioi_Tinh varchar(10) NOT NULL,
    CMND int NOT NULL,
    CONSTRAINT Khach_Hang_pk PRIMARY KEY (ID_KH)
);

-- Table: Loai_San_Pham
CREATE TABLE Loai_San_Pham (
    Ma_SP int NOT NULL,
    So_Luong int NOT NULL,
    Don_Gia int NOT NULL,
    Tong_Tien int NOT NULL,
    ID_KH int NOT NULL,
    Ngay_Giao date NOT NULL,
    Ma_HD int NOT NULL,
    Ma_Loai_SP int NOT NULL,
    San_Pham_Ma_SP int NOT NULL,
    CONSTRAINT Loai_San_Pham_pk PRIMARY KEY (Ma_Loai_SP)
);

-- Table: San_Pham
CREATE TABLE San_Pham (
    Ma_SP int NOT NULL,
    Ten_SP varchar(100) NOT NULL,
    Don_Gia int NOT NULL,
    Hinh_Anh varchar(100) NOT NULL,
    Ma_Loai_SP int NOT NULL,
    CONSTRAINT San_Pham_pk PRIMARY KEY (Ma_SP)
);

-- foreign keys
-- Reference: Hoa_Don_Chi_Tiet_Hoa_Don (table: Hoa_Don_Chi_Tiet)
ALTER TABLE Hoa_Don_Chi_Tiet ADD CONSTRAINT Hoa_Don_Chi_Tiet_Hoa_Don FOREIGN KEY Hoa_Don_Chi_Tiet_Hoa_Don (Hoa_Don_Ma_HD)
    REFERENCES Hoa_Don (Ma_HD);

-- Reference: Hoa_Don_Chi_Tiet_San_Pham (table: Hoa_Don_Chi_Tiet)
ALTER TABLE Hoa_Don_Chi_Tiet ADD CONSTRAINT Hoa_Don_Chi_Tiet_San_Pham FOREIGN KEY Hoa_Don_Chi_Tiet_San_Pham (San_Pham_Ma_SP)
    REFERENCES San_Pham (Ma_SP);

-- Reference: Hoa_Don_Khach_Hang (table: Hoa_Don)
ALTER TABLE Hoa_Don ADD CONSTRAINT Hoa_Don_Khach_Hang FOREIGN KEY Hoa_Don_Khach_Hang (Khach_Hang_ID_KH)
    REFERENCES Khach_Hang (ID_KH);

-- Reference: Loai_San_Pham_San_Pham (table: Loai_San_Pham)
ALTER TABLE Loai_San_Pham ADD CONSTRAINT Loai_San_Pham_San_Pham FOREIGN KEY Loai_San_Pham_San_Pham (San_Pham_Ma_SP)
    REFERENCES San_Pham (Ma_SP);

-- End of file.

