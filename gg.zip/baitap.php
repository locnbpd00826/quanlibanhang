<?php
$host_name = 'localhost'; 
$db_user = 'admin_bt';  
$db_pass = 'mK82XCXgTb'; 
$db_name = 'admin_bt';
mysql_pconnect($host_name,$db_user,$db_pass);
mysql_select_db($db_name); 
